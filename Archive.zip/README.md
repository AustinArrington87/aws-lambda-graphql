# aws-lambda-graphql
App for querying subredits with Lambda, Node, GraphQL
